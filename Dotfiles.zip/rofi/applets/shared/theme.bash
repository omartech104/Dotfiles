## Current Theme

type="$HOME/.config/rofi/applets/type-1"
style='style-1.rasi'
